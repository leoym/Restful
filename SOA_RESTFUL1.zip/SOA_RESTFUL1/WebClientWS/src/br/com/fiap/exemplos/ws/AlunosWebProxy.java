package br.com.fiap.exemplos.ws;

public class AlunosWebProxy implements br.com.fiap.exemplos.ws.AlunosWeb {
  private String _endpoint = null;
  private br.com.fiap.exemplos.ws.AlunosWeb alunosWeb = null;
  
  public AlunosWebProxy() {
    _initAlunosWebProxy();
  }
  
  public AlunosWebProxy(String endpoint) {
    _endpoint = endpoint;
    _initAlunosWebProxy();
  }
  
  private void _initAlunosWebProxy() {
    try {
      alunosWeb = (new br.com.fiap.exemplos.ws.AlunosWebServiceLocator()).getAlunosWebPort();
      if (alunosWeb != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)alunosWeb)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)alunosWeb)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (alunosWeb != null)
      ((javax.xml.rpc.Stub)alunosWeb)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public br.com.fiap.exemplos.ws.AlunosWeb getAlunosWeb() {
    if (alunosWeb == null)
      _initAlunosWebProxy();
    return alunosWeb;
  }
  
  public java.lang.String ola(java.lang.String arg0) throws java.rmi.RemoteException{
    if (alunosWeb == null)
      _initAlunosWebProxy();
    return alunosWeb.ola(arg0);
  }
  
  public java.lang.String novo(br.com.fiap.exemplos.ws.Aluno aluno) throws java.rmi.RemoteException{
    if (alunosWeb == null)
      _initAlunosWebProxy();
    return alunosWeb.novo(aluno);
  }
  
  public br.com.fiap.exemplos.ws.Aluno[] listar() throws java.rmi.RemoteException, br.com.fiap.exemplos.ws.Exception{
    if (alunosWeb == null)
      _initAlunosWebProxy();
    return alunosWeb.listar();
  }
  
  public boolean autenticado() throws java.rmi.RemoteException{
    if (alunosWeb == null)
      _initAlunosWebProxy();
    return alunosWeb.autenticado();
  }
  
  
}