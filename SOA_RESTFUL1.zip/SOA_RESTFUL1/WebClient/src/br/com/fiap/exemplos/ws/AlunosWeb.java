/**
 * AlunosWeb.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.fiap.exemplos.ws;

public interface AlunosWeb extends java.rmi.Remote {
    public java.lang.String ola(java.lang.String arg0) throws java.rmi.RemoteException;
    public boolean autenticado1() throws java.rmi.RemoteException;
    public br.com.fiap.exemplos.ws.NovoResponse novo(java.lang.String username, java.lang.String password, br.com.fiap.exemplos.ws.Aluno aluno) throws java.rmi.RemoteException;
    public br.com.fiap.exemplos.ws.Aluno[] listar(br.com.fiap.exemplos.ws.Listar parameters, java.lang.String username, java.lang.String password) throws java.rmi.RemoteException, br.com.fiap.exemplos.ws.Exception;
}
