package br.com.fiap.exemplos.serlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.fiap.exemplos.ws.Aluno;
import br.com.fiap.exemplos.ws.AlunosWeb;
import br.com.fiap.exemplos.ws.AlunosWebService;
import br.com.fiap.exemplos.ws.Listar;

@WebServlet("/Lista")
public class Lista extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    public Lista() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public void Teste() {
		/*
		List<Aluno> alunos = new ArrayList<Aluno>();
		AlunosWeb port = new AlunosWebService().getAlunosWebPort();
		
		Listar lista = new Listar();
		try {
			ListarResponse resposta = port.listar(lista, "Leo", "123");
			alunos = resposta.getReturn();
			for(Aluno b:alunos) {
				System.out.println("Nome: " + b.getNome());				
				System.out.println("Turma: " + b.getTurma());			
				System.out.println("M�dia: " + b.getMedia());				
				System.out.println("");				
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
	}

}
