/**
 * AlunosWebServiceLocator.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package br.com.fiap.exemplos.ws;

public class AlunosWebServiceLocator extends org.apache.axis.client.Service implements br.com.fiap.exemplos.ws.AlunosWebService {

    public AlunosWebServiceLocator() {
    }


    public AlunosWebServiceLocator(org.apache.axis.EngineConfiguration config) {
        super(config);
    }

    public AlunosWebServiceLocator(java.lang.String wsdlLoc, javax.xml.namespace.QName sName) throws javax.xml.rpc.ServiceException {
        super(wsdlLoc, sName);
    }

    // Use to get a proxy class for AlunosWebPort
    private java.lang.String AlunosWebPort_address = "http://l2901micro27:8080/Exemplo03/AlunosWebService";

    public java.lang.String getAlunosWebPortAddress() {
        return AlunosWebPort_address;
    }

    // The WSDD service name defaults to the port name.
    private java.lang.String AlunosWebPortWSDDServiceName = "AlunosWebPort";

    public java.lang.String getAlunosWebPortWSDDServiceName() {
        return AlunosWebPortWSDDServiceName;
    }

    public void setAlunosWebPortWSDDServiceName(java.lang.String name) {
        AlunosWebPortWSDDServiceName = name;
    }

    public br.com.fiap.exemplos.ws.AlunosWeb getAlunosWebPort() throws javax.xml.rpc.ServiceException {
       java.net.URL endpoint;
        try {
            endpoint = new java.net.URL(AlunosWebPort_address);
        }
        catch (java.net.MalformedURLException e) {
            throw new javax.xml.rpc.ServiceException(e);
        }
        return getAlunosWebPort(endpoint);
    }

    public br.com.fiap.exemplos.ws.AlunosWeb getAlunosWebPort(java.net.URL portAddress) throws javax.xml.rpc.ServiceException {
        try {
            br.com.fiap.exemplos.ws.AlunosWebPortBindingStub _stub = new br.com.fiap.exemplos.ws.AlunosWebPortBindingStub(portAddress, this);
            _stub.setPortName(getAlunosWebPortWSDDServiceName());
            return _stub;
        }
        catch (org.apache.axis.AxisFault e) {
            return null;
        }
    }

    public void setAlunosWebPortEndpointAddress(java.lang.String address) {
        AlunosWebPort_address = address;
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        try {
            if (br.com.fiap.exemplos.ws.AlunosWeb.class.isAssignableFrom(serviceEndpointInterface)) {
                br.com.fiap.exemplos.ws.AlunosWebPortBindingStub _stub = new br.com.fiap.exemplos.ws.AlunosWebPortBindingStub(new java.net.URL(AlunosWebPort_address), this);
                _stub.setPortName(getAlunosWebPortWSDDServiceName());
                return _stub;
            }
        }
        catch (java.lang.Throwable t) {
            throw new javax.xml.rpc.ServiceException(t);
        }
        throw new javax.xml.rpc.ServiceException("There is no stub implementation for the interface:  " + (serviceEndpointInterface == null ? "null" : serviceEndpointInterface.getName()));
    }

    /**
     * For the given interface, get the stub implementation.
     * If this service has no port for the given interface,
     * then ServiceException is thrown.
     */
    public java.rmi.Remote getPort(javax.xml.namespace.QName portName, Class serviceEndpointInterface) throws javax.xml.rpc.ServiceException {
        if (portName == null) {
            return getPort(serviceEndpointInterface);
        }
        java.lang.String inputPortName = portName.getLocalPart();
        if ("AlunosWebPort".equals(inputPortName)) {
            return getAlunosWebPort();
        }
        else  {
            java.rmi.Remote _stub = getPort(serviceEndpointInterface);
            ((org.apache.axis.client.Stub) _stub).setPortName(portName);
            return _stub;
        }
    }

    public javax.xml.namespace.QName getServiceName() {
        return new javax.xml.namespace.QName("http://ws.exemplos.fiap.com.br/", "AlunosWebService");
    }

    private java.util.HashSet ports = null;

    public java.util.Iterator getPorts() {
        if (ports == null) {
            ports = new java.util.HashSet();
            ports.add(new javax.xml.namespace.QName("http://ws.exemplos.fiap.com.br/", "AlunosWebPort"));
        }
        return ports.iterator();
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(java.lang.String portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        
if ("AlunosWebPort".equals(portName)) {
            setAlunosWebPortEndpointAddress(address);
        }
        else 
{ // Unknown Port Name
            throw new javax.xml.rpc.ServiceException(" Cannot set Endpoint Address for Unknown Port" + portName);
        }
    }

    /**
    * Set the endpoint address for the specified port name.
    */
    public void setEndpointAddress(javax.xml.namespace.QName portName, java.lang.String address) throws javax.xml.rpc.ServiceException {
        setEndpointAddress(portName.getLocalPart(), address);
    }

}
