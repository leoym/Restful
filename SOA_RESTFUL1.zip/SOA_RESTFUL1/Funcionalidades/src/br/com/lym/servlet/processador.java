package br.com.lym.servlet;

import javax.imageio.*;

import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/processador")
public class processador extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public processador() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String resposta = processaImagem(); 
		response.getWriter().append("Resposta: ").append(resposta);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
	
	public String processaImagem() {
		String resposta = "";
		BufferedImage img = null;
		Image img1 = null;
		int altura = 0;
		int largura = 0;
		try {
		    img = ImageIO.read(new File("c:\\temp\\download.png"));
		    altura = img.getHeight();
		    largura = img.getWidth();
		    
		    File outputfile = new File("c:\\temp\\download_thumb.png");
		    img.getScaledInstance(100, 100, 0);
		    ImageIO.write(img, "png", outputfile);
		    resposta = "Altura: " + altura + "/largura: " + largura;
		    
		} catch (IOException e) {
			e.getStackTrace();
			resposta = "Erro";
		}		
		return resposta ;
	}

}
