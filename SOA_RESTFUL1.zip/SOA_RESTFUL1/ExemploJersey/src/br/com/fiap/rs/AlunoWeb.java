package br.com.fiap.rs;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("alunos")
public class AlunoWeb {
	static private List<Aluno> alunos;
	
	static {
		alunos = new ArrayList<Aluno>();
		
		Aluno a = new Aluno();
		a.setNome("Leonardo");
		a.setTurma("27SCJ");
		a.setMedia(7.0);
		alunos.add(a);
		
		Aluno b = new Aluno();
		b.setNome("Leonardo");
		b.setTurma("27SCJ");
		b.setMedia(7.0);
		alunos.add(b);		
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Aluno> getAlunos() {
		return alunos;
	}
}
