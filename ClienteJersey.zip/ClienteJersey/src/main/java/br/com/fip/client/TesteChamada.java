package br.com.fip.client;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation.Builder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

public class TesteChamada {
	
	public static void main (String[] args){
		System.out.println("Teste retorno");						
		Text();
		System.out.println("Lista de alunos");				
		ListaXml();
		System.out.println("Aluno");				
		ListaGetXml();	
		System.out.println("Cadastrando aluno");				
		//TesteChamadaPOST();
		System.out.println("Atualizando aluno");				
		//TesteChamadaPUT();
		System.out.println("Removendo aluno");				
		//TesteChamadaDELETE();
		System.out.println("");		
	}
	
	public static void ListaXml() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("alunos");
		Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.get();
		Alunos alunos = response.readEntity(Alunos.class);
		for(Aluno a:alunos.getAlunoList()) {
			System.out.println(a.getNome() + " - " + a.getTurma() + " / M�dia: " + a.getMedia());				
		}
	}

	public static void ListaGetXml() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("alunos").path("1");
		Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.get();
		Aluno aluno = response.readEntity(Aluno.class);

		System.out.println(aluno.getNome() + " - " + aluno.getTurma() + " / M�dia: " + aluno.getMedia());			
	}

	
	public static void Text() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("exemplo");
		Builder invocationBuilder = webTarget.request(MediaType.TEXT_PLAIN);
		Response response = invocationBuilder.get();
		String retorno = response.readEntity(String.class);
		System.out.println(retorno);	
	}
	
	public static void TesteChamadaPOST() {
		Aluno aluno = new Aluno();	
		aluno.setNome("");
		aluno.setTurma("");
		aluno.setMedia(1.0);
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("alunos");
		Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.post(Entity.entity(aluno,MediaType.APPLICATION_XML));
		Retorno retorno = response.readEntity(Retorno.class);
		System.out.println(retorno);			
	}
	
	public static void TesteChamadaPUT() {
		Aluno aluno = new Aluno();	
		aluno.setNome("");
		aluno.setTurma("");
		aluno.setMedia(1.0);
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("alunos").path("X");
		Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.put(Entity.entity(aluno,MediaType.APPLICATION_XML));
		Retorno retorno = response.readEntity(Retorno.class);
		System.out.println(retorno);			
	}
	
	public static void TesteChamadaDELETE() {
		Client client = ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://10.10.035.31:8080/ExemploJersey").path("alunos").path("X");
		Builder invocationBuilder = webTarget.request(MediaType.APPLICATION_XML);
		Response response = invocationBuilder.delete();
		Retorno retorno = response.readEntity(Retorno.class);
		System.out.println(retorno);			
	}
}
